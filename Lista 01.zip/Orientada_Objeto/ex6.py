num = int(input("Qual o numero de maças comparadas ?"))
valor = 0
if num < 12:
    valor = num * 1.30
    print(valor)
else:
    print(num)
