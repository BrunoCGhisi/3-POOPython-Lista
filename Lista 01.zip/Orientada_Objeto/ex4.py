farenheit = float(input("QUal o farenheit mano "))
Celsius = ((farenheit-32)/9)*5
print(Celsius)
