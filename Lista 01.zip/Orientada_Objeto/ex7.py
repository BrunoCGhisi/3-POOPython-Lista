def calculomedia(x,y):
    media = (x + y)/2
    print (media)

def main():
    n1 = float(input(" Qual a sua nota ? "))
    n2 = float(input(" Qual a sua nota ? "))
    calculomedia(n1,n2)
main()
