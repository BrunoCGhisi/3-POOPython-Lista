base = int(input("Base do retangulo: "))
altura = int(input("Altura do retangulo: "))
area = base*altura
print(f" a area do retangulo é {area}")
