bruto = float(input("Qual o preço do carro: "))
fabrica = (bruto*0.28) + bruto
total = (fabrica*0.45) + fabrica
print (total)

